# install packages needed to execute artifact
install.packages("car")
install.packages("Hmisc")
install.packages("hexbin")
install.packages("HH")
install.packages("scales")

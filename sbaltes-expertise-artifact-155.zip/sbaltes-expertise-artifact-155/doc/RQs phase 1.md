# Research Questions Phase 1

**RQ1:** Which characteristics do developers assign to software development novices and which to experts?

**RQ2:** Which challenges do developers face in their daily work?
